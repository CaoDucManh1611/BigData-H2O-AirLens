Source: https://open-meteo.com/en/docs/air-quality-api
Downloaded: 2026-10-05
Cities: location_id 0=Ha Noi; 1=Da Nang; 2=Ho Chi Minh City.
Timezone: Asia/Ho_Chi_Minh (UTC+7).
Historical file: 2023-01-01 to 2026-10-04; 98,856 hourly records total.
Forecast file: 2026-10-05 to 2026-10-09. Keep separate from training/evaluation data.
Variables: PM10, PM2.5, CO, NO2, SO2, O3 (micrograms/m3) and US AQI.
Data are CAMS atmospheric model outputs served by Open-Meteo, not ground-station observations. Coordinates returned are representative model grid cells, not city-wide measurements.
Raw CSV contains metadata rows followed by a blank line, then the hourly table. Read hourly rows with skiprows=5.
Attribution: Open-Meteo and CAMS.
